#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
大模型集成模块初始化
"""

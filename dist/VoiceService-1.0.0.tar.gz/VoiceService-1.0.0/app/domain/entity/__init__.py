#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
实体模块初始化
"""

#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
仓储接口模块初始化
"""

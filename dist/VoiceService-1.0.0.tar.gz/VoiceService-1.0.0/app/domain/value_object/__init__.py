#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
值对象包
"""

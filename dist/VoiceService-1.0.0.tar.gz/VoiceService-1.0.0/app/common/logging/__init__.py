#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
日志模块初始化
"""
